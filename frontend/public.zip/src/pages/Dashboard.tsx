import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { 
  Users, 
  UserCheck, 
  FileText, 
  TrendingUp, 
  Activity, 
  Zap,
  ArrowUpRight,
  Calendar,
  Clock,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import { contactsAPI, ownersAPI, templatesAPI } from '../services/api';

const Dashboard: React.FC = () => {
  const { data: contacts } = useQuery({
    queryKey: ['contacts'],
    queryFn: () => contactsAPI.getAll(),
  });

  const { data: owners } = useQuery({
    queryKey: ['owners'],
    queryFn: () => ownersAPI.getAll(),
  });

  const { data: templates } = useQuery({
    queryKey: ['templates'],
    queryFn: () => templatesAPI.getAll(),
  });

  const stats = [
    {
      name: 'Total Contacts',
      value: contacts?.data?.length || 0,
      change: '+12%',
      changeType: 'positive',
      icon: Users,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50',
      iconColor: 'text-blue-600',
    },
    {
      name: 'Data Owners',
      value: owners?.data?.length || 0,
      change: '+8%',
      changeType: 'positive',
      icon: UserCheck,
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50',
      iconColor: 'text-green-600',
    },
    {
      name: 'Message Templates',
      value: templates?.data?.length || 0,
      change: '+15%',
      changeType: 'positive',
      icon: FileText,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50',
      iconColor: 'text-purple-600',
    },
    {
      name: 'Active Campaigns',
      value: 3,
      change: '+2',
      changeType: 'positive',
      icon: TrendingUp,
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-50',
      iconColor: 'text-orange-600',
    },
  ];

  const recentActivities = [
    {
      id: 1,
      type: 'contact_added',
      message: 'New contact "John Doe" added',
      time: '2 minutes ago',
      icon: Users,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
    },
    {
      id: 2,
      type: 'template_created',
      message: 'Template "Welcome Message" created',
      time: '15 minutes ago',
      icon: FileText,
      color: 'text-purple-600',
      bgColor: 'bg-purple-50',
    },
    {
      id: 3,
      type: 'message_sent',
      message: 'Message sent to 25 contacts',
      time: '1 hour ago',
      icon: CheckCircle,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
    },
    {
      id: 4,
      type: 'ingestion_completed',
      message: 'Zoho CRM ingestion completed',
      time: '2 hours ago',
      icon: Zap,
      color: 'text-orange-600',
      bgColor: 'bg-orange-50',
    },
  ];

  const quickActions = [
    {
      name: 'Add Contact',
      description: 'Create a new contact entry',
      icon: Users,
      href: '/contacts',
      color: 'from-blue-500 to-blue-600',
      hoverColor: 'hover:from-blue-600 hover:to-blue-700',
    },
    {
      name: 'Create Template',
      description: 'Design a new message template',
      icon: FileText,
      href: '/templates',
      color: 'from-purple-500 to-purple-600',
      hoverColor: 'hover:from-purple-600 hover:to-purple-700',
    },
    {
      name: 'Send Message',
      description: 'Send a message to contacts',
      icon: TrendingUp,
      href: '/messages',
      color: 'from-green-500 to-green-600',
      hoverColor: 'hover:from-green-600 hover:to-green-700',
    },
    {
      name: 'Run Ingestion',
      description: 'Import data from external sources',
      icon: Zap,
      href: '/ingestion',
      color: 'from-orange-500 to-orange-600',
      hoverColor: 'hover:from-orange-600 hover:to-orange-700',
    },
  ];

  return (
    <div className="space-y-8 relative">
      {/* Background Decorative Elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-20 right-20 w-64 h-64 bg-gradient-to-br from-primary-100/30 to-purple-100/30 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-48 h-48 bg-gradient-to-tr from-indigo-100/30 to-blue-100/30 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }}></div>
      </div>
      {/* Welcome Section */}
      <div className="text-center animate-fade-in-up">
        <h1 className="text-4xl font-bold gradient-text mb-4">
          Welcome to IKF PhoneBook! 👋
        </h1>
        <p className="text-xl text-gray-600 max-w-2xl mx-auto">
          Here's what's happening with your professional contact management system today
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
                         <div 
               key={stat.name}
               className="card-interactive group animate-fade-in-up relative overflow-hidden"
               style={{ animationDelay: `${index * 100}ms` }}
             >
               <div className="absolute inset-0 bg-gradient-to-br from-white to-gray-50/50 opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
               <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 transform -skew-y-1"></div>
                             <div className="relative z-10 p-6">
                 <div className="flex items-center justify-between">
                   <div className={`w-12 h-12 rounded-xl bg-gradient-to-r ${stat.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-200`}>
                     <Icon className="h-6 w-6 text-white" />
                   </div>
                   <div className={`text-sm font-medium ${stat.changeType === 'positive' ? 'text-green-600' : 'text-red-600'}`}>
                     {stat.change}
                   </div>
                 </div>
                 <div className="mt-4">
                   <p className="text-2xl font-bold text-gray-900">{stat.value}</p>
                   <p className="text-sm text-gray-600">{stat.name}</p>
                 </div>
                 <div className="mt-4 flex items-center text-sm text-gray-500">
                   <TrendingUp className="h-4 w-4 mr-1" />
                   <span>From last month</span>
                 </div>
               </div>
            </div>
          );
        })}
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Quick Actions */}
        <div className="lg:col-span-2 space-y-6">
          <div className="card animate-slide-in-left">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Zap className="h-5 w-5 mr-2 text-primary-600" />
                Quick Actions
              </h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {quickActions.map((action, index) => {
                  const Icon = action.icon;
                  return (
                    <a
                      key={action.name}
                      href={action.href}
                      className="group block p-4 rounded-xl border border-gray-200 hover:border-gray-300 transition-all duration-200 ease-in-out hover:scale-105 hover:shadow-md"
                    >
                      <div className="flex items-center space-x-3">
                        <div className={`w-10 h-10 rounded-lg bg-gradient-to-r ${action.color} ${action.hoverColor} flex items-center justify-center transition-all duration-200 group-hover:scale-110`}>
                          <Icon className="h-5 w-5 text-white" />
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900 group-hover:text-primary-600 transition-colors duration-200">
                            {action.name}
                          </h3>
                          <p className="text-sm text-gray-500">{action.description}</p>
                        </div>
                        <ArrowUpRight className="h-4 w-4 text-gray-400 group-hover:text-primary-600 group-hover:translate-x-1 group-hover:-translate-y-1 transition-all duration-200" />
                      </div>
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Recent Activities */}
          <div className="card animate-slide-in-left" style={{ animationDelay: '200ms' }}>
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Activity className="h-5 w-5 mr-2 text-primary-600" />
                Recent Activities
              </h2>
              <div className="space-y-4">
                {recentActivities.map((activity, index) => {
                  const Icon = activity.icon;
                  return (
                    <div 
                      key={activity.id}
                      className="flex items-center space-x-3 p-3 rounded-lg hover:bg-gray-50 transition-colors duration-200 group animate-fade-in-up"
                      style={{ animationDelay: `${index * 100}ms` }}
                    >
                      <div className={`w-8 h-8 rounded-lg ${activity.bgColor} flex items-center justify-center group-hover:scale-110 transition-transform duration-200`}>
                        <Icon className={`h-4 w-4 ${activity.color}`} />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">{activity.message}</p>
                        <p className="text-xs text-gray-500 flex items-center">
                          <Clock className="h-3 w-3 mr-1" />
                          {activity.time}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* System Status */}
          <div className="card animate-slide-in-right">
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <CheckCircle className="h-5 w-5 mr-2 text-green-600" />
                System Status
              </h2>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Database</span>
                  <span className="flex items-center text-sm text-green-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    Online
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">API Services</span>
                  <span className="flex items-center text-sm text-green-600">
                    <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                    Healthy
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">External Integrations</span>
                  <span className="flex items-center text-sm text-yellow-600">
                    <div className="w-2 h-2 bg-yellow-500 rounded-full mr-2 animate-pulse"></div>
                    Warning
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Upcoming Tasks */}
          <div className="card animate-slide-in-right" style={{ animationDelay: '200ms' }}>
            <div className="p-6">
              <h2 className="text-xl font-semibold text-gray-900 mb-4 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-primary-600" />
                Upcoming Tasks
              </h2>
              <div className="space-y-3">
                <div className="p-3 bg-blue-50 rounded-lg border-l-4 border-blue-500">
                  <p className="text-sm font-medium text-blue-900">Data Backup</p>
                  <p className="text-xs text-blue-600">Scheduled for tomorrow</p>
                </div>
                <div className="p-3 bg-purple-50 rounded-lg border-l-4 border-purple-500">
                  <p className="text-sm font-medium text-purple-900">Template Review</p>
                  <p className="text-xs text-purple-600">Due in 2 days</p>
                </div>
                <div className="p-3 bg-orange-50 rounded-lg border-l-4 border-orange-500">
                  <p className="text-sm font-medium text-orange-900">System Update</p>
                  <p className="text-xs text-orange-600">Scheduled for next week</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
