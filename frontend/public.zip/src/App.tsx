import React from 'react';
import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Contacts from './pages/Contacts';
import ContactDetail from './pages/ContactDetail';
import Owners from './pages/Owners';
import OwnerDetail from './pages/OwnerDetail';
import Templates from './pages/Templates';
import TemplateDetail from './pages/TemplateDetail';
import Messages from './pages/Messages';
import Ingestion from './pages/Ingestion';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 5 * 60 * 1000, // 5 minutes
      retry: 1,
    },
  },
});

const router = createBrowserRouter([
  {
    path: '/login',
    element: <Login />,
  },
  {
    path: '/',
    element: <Layout><Dashboard /></Layout>,
  },
  {
    path: '/contacts',
    element: <Layout><Contacts /></Layout>,
  },
  {
    path: '/contacts/:id',
    element: <Layout><ContactDetail /></Layout>,
  },
  {
    path: '/owners',
    element: <Layout><Owners /></Layout>,
  },
  {
    path: '/owners/:id',
    element: <Layout><OwnerDetail /></Layout>,
  },
  {
    path: '/templates',
    element: <Layout><Templates /></Layout>,
  },
  {
    path: '/templates/:id',
    element: <Layout><TemplateDetail /></Layout>,
  },
  {
    path: '/messages',
    element: <Layout><Messages /></Layout>,
  },
  {
    path: '/ingestion',
    element: <Layout><Ingestion /></Layout>,
  },
]);

const App: React.FC = () => {
  return (
    <QueryClientProvider client={queryClient}>
      <RouterProvider router={router} />
    </QueryClientProvider>
  );
};

export default App;
