import React, { useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { Database, Play, CheckCircle, AlertCircle, Clock, RefreshCw } from 'lucide-react';
import { ingestionAPI } from '../services/api';

const Ingestion: React.FC = () => {
  const queryClient = useQueryClient();
  const [isRunning, setIsRunning] = useState<string | null>(null);

  const { data: latestImport, refetch } = useQuery({
    queryKey: ['latestImport'],
    queryFn: () => ingestionAPI.getLatestImport(),
  });

  const runZohoMutation = useMutation({
    mutationFn: () => ingestionAPI.runZoho(),
    onSuccess: () => {
      setIsRunning(null);
      refetch();
    },
  });

  const runGmailMutation = useMutation({
    mutationFn: () => ingestionAPI.runGmail(),
    onSuccess: () => {
      setIsRunning(null);
      refetch();
    },
  });

  const runInvoiceMutation = useMutation({
    mutationFn: () => ingestionAPI.runInvoice(),
    onSuccess: () => {
      setIsRunning(null);
      refetch();
    },
  });

  const runMobileMutation = useMutation({
    mutationFn: () => ingestionAPI.runMobile(),
    onSuccess: () => {
      setIsRunning(null);
      refetch();
    },
  });

  const cleanAndMergeMutation = useMutation({
    mutationFn: () => ingestionAPI.cleanAndMerge(),
    onSuccess: () => {
      setIsRunning(null);
      refetch();
    },
  });

  const ingestionSources = [
    {
      id: 'zoho',
      name: 'Zoho CRM',
      description: 'Import contacts and leads from Zoho CRM',
      icon: Database,
      color: 'bg-blue-500',
      mutation: runZohoMutation,
    },
    {
      id: 'gmail',
      name: 'Gmail Contacts',
      description: 'Import contacts from Gmail address book',
      icon: Database,
      color: 'bg-red-500',
      mutation: runGmailMutation,
    },
    {
      id: 'invoice',
      name: 'Invoice System',
      description: 'Import customer data from invoice system',
      icon: Database,
      color: 'bg-green-500',
      mutation: runInvoiceMutation,
    },
    {
      id: 'mobile',
      name: 'Mobile Contacts',
      description: 'Import contacts from mobile device',
      icon: Database,
      color: 'bg-purple-500',
      mutation: runMobileMutation,
    },
  ];

  const handleRunIngestion = (sourceId: string) => {
    setIsRunning(sourceId);
    const source = ingestionSources.find(s => s.id === sourceId);
    if (source) {
      source.mutation.mutate();
    }
  };

  const getStatusIcon = (status?: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'failed':
        return <AlertCircle className="h-5 w-5 text-red-500" />;
      case 'running':
        return <Clock className="h-5 w-5 text-yellow-500" />;
      default:
        return <Clock className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusText = (status?: string) => {
    switch (status) {
      case 'completed':
        return 'Completed';
      case 'failed':
        return 'Failed';
      case 'running':
        return 'Running';
      default:
        return 'Not Started';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Data Ingestion</h1>
        <p className="text-gray-600">Import and sync data from various sources</p>
      </div>

      {/* Ingestion Sources */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {ingestionSources.map((source) => {
          const Icon = source.icon;
          const isCurrentlyRunning = isRunning === source.id;
          const mutation = source.mutation;
          
          return (
            <div key={source.id} className="bg-white shadow rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center">
                  <div className={`${source.color} p-2 rounded-lg`}>
                    <Icon className="h-6 w-6 text-white" />
                  </div>
                  <div className="ml-3">
                    <h3 className="text-lg font-medium text-gray-900">{source.name}</h3>
                    <p className="text-sm text-gray-500">{source.description}</p>
                  </div>
                </div>
              </div>

              <div className="flex items-center justify-between">
                <button
                  onClick={() => handleRunIngestion(source.id)}
                  disabled={isCurrentlyRunning || mutation.isPending}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {isCurrentlyRunning || mutation.isPending ? (
                    <>
                      <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                      Running...
                    </>
                  ) : (
                    <>
                      <Play className="h-4 w-4 mr-2" />
                      Run Import
                    </>
                  )}
                </button>

                <div className="flex items-center text-sm text-gray-500">
                  {getStatusIcon(mutation.data?.data?.status)}
                  <span className="ml-2">{getStatusText(mutation.data?.data?.status)}</span>
                </div>
              </div>

              {mutation.error && (
                <div className="mt-3 text-sm text-red-600">
                  Error: {mutation.error.message}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Clean and Merge */}
      <div className="bg-white shadow rounded-lg p-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-lg font-medium text-gray-900">Clean and Merge</h3>
            <p className="text-sm text-gray-500">
              Clean duplicate contacts and merge data from all sources
            </p>
          </div>
          <button
            onClick={() => {
              setIsRunning('clean-merge');
              cleanAndMergeMutation.mutate();
            }}
            disabled={isRunning === 'clean-merge' || cleanAndMergeMutation.isPending}
            className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isRunning === 'clean-merge' || cleanAndMergeMutation.isPending ? (
              <>
                <RefreshCw className="h-4 w-4 mr-2 animate-spin" />
                Processing...
              </>
            ) : (
              <>
                <CheckCircle className="h-4 w-4 mr-2" />
                Clean & Merge
              </>
            )}
          </button>
        </div>

        {cleanAndMergeMutation.error && (
          <div className="text-sm text-red-600">
            Error: {cleanAndMergeMutation.error.message}
          </div>
        )}
      </div>

      {/* Latest Import Status */}
      <div className="bg-white shadow rounded-lg">
        <div className="px-4 py-5 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg leading-6 font-medium text-gray-900">Latest Import Status</h3>
            <button
              onClick={() => refetch()}
              className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-500"
            >
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </button>
          </div>

          {latestImport?.data ? (
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <dt className="text-sm font-medium text-gray-500">Source</dt>
                  <dd className="mt-1 text-sm text-gray-900">{latestImport.data.source || 'Unknown'}</dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Status</dt>
                  <dd className="mt-1 flex items-center text-sm text-gray-900">
                    {getStatusIcon(latestImport.data.status)}
                    <span className="ml-2">{getStatusText(latestImport.data.status)}</span>
                  </dd>
                </div>
                <div>
                  <dt className="text-sm font-medium text-gray-500">Last Run</dt>
                  <dd className="mt-1 text-sm text-gray-900">
                    {latestImport.data.timestamp ? new Date(latestImport.data.timestamp).toLocaleString() : 'Unknown'}
                  </dd>
                </div>
              </div>
            </div>
          ) : (
            <div className="text-center py-8 text-gray-500">
              <Database className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No import history</h3>
              <p className="mt-1 text-sm text-gray-500">
                Run your first import to see status here
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Ingestion;
